// JavaScript test file with intentional formatting issues
const name = "test";
let age = 25;

function greet(name) {
  return "Hello, " + name + "!";
}

const obj = { a: 1, b: 2, c: 3 };

console.log(greet(name));
