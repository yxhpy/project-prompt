# Python test with style issues


def add(a, b):
    return a + b


print(add(1, 2))
