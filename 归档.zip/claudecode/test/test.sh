#!/usr/bin/env bash

echo  "Hello"  $1

echo   $( date )