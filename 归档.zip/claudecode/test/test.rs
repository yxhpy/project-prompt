fn add(a: i32, b: i32) -> i32 {
    a + b
}

fn main() {
    println!("sum={}", add(1, 2));
}
